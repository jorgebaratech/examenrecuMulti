package com.example.examenrecuperacion.controller

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.examenrecuperacion.R
import com.example.examenrecuperacion.model.Pelicula

class PeliculasAdapter(private val context: Context, private val layout: Int, private val list: List<Pelicula>):
    BaseAdapter() {
    override fun getCount(): Int {
        return list.size
    }

    override fun getItem(posicion: Int): Any {
        return list[posicion]
    }

    override fun getItemId(id: Int): Long {
        return id.toLong()
    }

    override fun getView(posicion: Int, convertView: View?, parent: ViewGroup?): View {
        var view=convertView
        val layoutInflater= LayoutInflater.from(context)
        view=layoutInflater.inflate(R.layout.item_peliculas,null)
        var Pelicula=list.get(posicion)
        var textName =view.findViewById<TextView>(R.id.nombre)
        var image =view.findViewById<ImageView>(R.id.imagen_pelicula)
        textName.text=Pelicula.titulo
        image.setImageResource(Pelicula.imagen)

        return view

    }



}