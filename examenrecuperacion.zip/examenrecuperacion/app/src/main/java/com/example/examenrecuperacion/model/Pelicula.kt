package com.example.examenrecuperacion.model

import com.example.examenrecuperacion.R


class Pelicula (val id: Int,
                val titulo: String,
                val imagen: Int,
                val premios: String,
                val director: String,
                val actorPrincipal: String,
                val actrizPrincipal: String,
                val duracion: String,
                val genero: String){
    companion object{
        fun crearCartelera():ArrayList<Pelicula>{

            val Pelicula= arrayListOf<Pelicula>()

            Pelicula(1,"Nomadland", R.drawable.nomadland,"Mejor Pelicula","Chloé Zhao", "","Frances McDormand","1h 48m","Drama")
            Pelicula(2,"The Father", R.drawable.thefather,"Mejor Guion Adaptado","Florian Zeller","Anthony Hopkins","Olivia Colman","1h 37m", "Drama")
            Pelicula(3,"The Trial of the Chicago 7", R.drawable.thetrialofchicago7,"Mejor Guion Original","Aaron Sorkin","Sacha Baron Cohen","","2h 10m","Drama")
            Pelicula(4,"Judas and the Black Messiah", R.drawable.judastheblackmessiah,"Mejor Actor de Reparto (Daniel Kaluuya)","Shaka King","","","2h 6m","Drama")
            Pelicula(5,"Minari",R.drawable.minari, "Mejor Actor de Reparto (Yuh-Jung Youn)","Lee Isaac Chung","Steven Yeun","Yeri Han","1h 55m","Drama")
            Pelicula(6,"Promising Young Woman", R.drawable.promising,"Mejor Guion Original","Emerald Fennell","","Carey Mulligan","1h 53m","Thriller")
            Pelicula(7,"Sound of Metal", R.drawable.soundofmetal,"Mejor Edicion de Sonido, Mejor Edicion","Darius Marder","Riz Ahmed","","2h","Drama")
            Pelicula(8,"Ma Raineys Black Bottom", R.drawable.maraineysblack,"Mejor Diseño de Vestuario,Mejor Maquillaje y Peinado","George C. Wolfe", "Chadwick Boseman","Viola Davis","1h 34m","Drama")
            Pelicula(9,"Soul", R.drawable.soul,"Mejor Pelicula Animada, Mejor Banda Sonora Original","Pete Docter","","","1h 40m","Animación")
            Pelicula(10,"Mank",R.drawable.mank,"Mejor Fotografia, Mejor Diseño de Produccion","David Fincher","Gary Oldman","","2h 11m","Drama")
            Pelicula(11,"Another Round", R.drawable.anotherround,"Mejor Pelicula Internacional","Thomas Vinterberg","Mads Mikkelsen","","1h 57m","Drama")

            return Pelicula

        }
    }



}

