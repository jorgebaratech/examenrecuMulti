package com.example.examenrecuperacion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.example.examenrecuperacion.controller.PeliculasAdapter
import com.example.examenrecuperacion.model.Pelicula



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var peliculas=ArrayList<Pelicula>()
        peliculas.addAll(Pelicula.crearCartelera())

        var listView=findViewById<ListView>(R.id.listview)
        var miadapter=PeliculasAdapter(this,R.layout.item_peliculas,peliculas)
        listView.adapter=miadapter


    }
}